#ifndef MAIN
#define MAIN


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


#include "dtd.h"
#include "xml.h"
#include "menu.h"

#define false 0
#define true 1
typedef GRegex GRegex;
typedef GMatchInfo GMatchInfo;


#endif
